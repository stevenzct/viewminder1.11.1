﻿using System;

namespace viewminder1
{
    internal class Guna2PictureBox1_Click
    {
        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}